import matplotlib.pyplot as plt
import os.path
import numpy as np
import PIL 
from PIL import Image 
directory = os.path.dirname(os.path.abspath(__file__))
filename = os.path.join(directory, 'Goku_Vegeta_ImageAlgorithmcopy.jpg')
img = plt.imread(filename)
fig, ax = plt.subplots(1,1)
ax.imshow(img,interpolation='none')
def open_file(filename, isPlt = True):
    directory = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(directory,filename)
    if isPlt:
        img = plt.imread(filepath)
    else:
        img = PIL.Image.open(filepath)
    return img
        
def save_file(image,filename):
    directory = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(directory,filename)
    image.save(filepath) 
       
directory = os.path.dirname(os.path.abspath(__file__))
filename = os.path.join(directory, 'Goku_Vegeta_ImageAlgorithmcopy.jpg')
img = plt.imread(filename)
fig, ax = plt.subplots(1,1)
ax.imshow(img,interpolation='none')

height = len(img)
width = len(img[0])
for row in range(0,370):
    for column in range(0,500):
        if sum(img[row][column])>=300 and sum(img[row][column])<=400:
            img[row][column] = [0,255,255]
for row in range(0,height/2):
    for column in range(width/2,width):
        if sum(img[row][column])>=300 and sum(img[row][column])<=450:
           img[row][column] = [0,255,255] 
fig.show()
img1= PIL.Image.fromarray(img)
save_file(img1,"Goku_Vegeta_Image2.jpg")


directory = os.path.dirname(os.path.abspath(__file__))
Goku_Vegeta_filename = os.path.join(directory, 'Goku_Vegeta_Image2.jpg')
Goku_Vegeta_img = PIL.Image.open(Goku_Vegeta_filename)
Goku_Vegeta_resize = Goku_Vegeta_img.resize((700,450))
fig2, axes2 = plt.subplots(1,2)
axes2[0].imshow(Goku_Vegeta_img)
axes2[1].imshow(Goku_Vegeta_resize)
ax.imshow(img,interpolation='none')
fig2.show()

'''
Goku_Vegeta_resize.save('Goku_Vegeta_resize.jpg')
'''
img3 = 'Goku_Vegeta_resize.jpg'
img3 = PIL.Image.fromarray(img)
save_file(img3,'Goku_Vegeta_resize_PIL.jpg') 
    
directory = os.path.dirname(os.path.abspath(__file__))
filename = os.path.join(directory, 'fire_ImageAlgorithm.jpg')
img = plt.imread(filename)
fig, ax = plt.subplots(1,1)
ax.imshow(img,interpolation='none')
fig.show()    
    
img4 ='fire_ImageAlgorithm.jpg'
img4 = PIL.Image.fromarray(img)
save_file(img4,'fire_ImagePIL.jpg')     

directory = os.path.dirname(os.path.abspath(__file__))
fireImagePIL_file = os.path.join(directory, 'fire_ImagePIL.jpg')
fire_img = PIL.Image.open(fireImagePIL_file)
fig, ax = plt.subplots(1,2)
ax[0].imshow(fire_img,interpolation='none')
ax[1].imshow(fire_img,interpolation='none')
ax[1].set_xticks(range(1050,1410,100))
ax[1].set_xlim(1050,1400)
ax[1].set_ylim(1100, 850)
fig.show()    

directory = os.path.dirname(os.path.abspath(__file__))   
fire_file = os.path.join(directory, 'fire_ImagePIL.jpg')
fire_img = PIL.Image.open(fire_file)
fire_PIL_image_resize= fire_img.resize((29,76)) # w and h measured in plt
fig2, axes2 = plt.subplots(1, 2)
axes2[0].imshow(fire_img)
axes2[1].imshow(fire_PIL_image_resize)
fig2.show()
#vegeta y:430,354 x:500,529
#goku x: 720,748 y:414,340
#eyes.
directory = os.path.dirname(os.path.abspath(__file__))
goku_vegeta_file = os.path.join(directory, 'Goku_Vegeta_resize_PIL.jpg')
Goku_PIL_img = PIL.Image.open(goku_vegeta_file)
fig, ax = plt.subplots(1,1)
ax.imshow(img,interpolation='none')
fig.show()

img5 = 'fire_ImagePIL.jpg'
img5 = PIL.Image.fromarray(img)
save_file(img5,'fire_imagePILResize.jpg')

image = Image.open('Goku_Vegeta_resize_PIL.jpg')
logo = Image.open('fire_imagePILResize.jpg')
image_copy = image.copy()
position = ((image_copy.width - logo.width), (image_copy.height - logo.height))
image_copy.paste(logo, position)
image_copy.save('pasted_image1.jpg')
fig.show()

